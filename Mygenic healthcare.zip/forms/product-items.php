<?php include("header.php"); ?>
<?php include("carousel.php"); ?>

    <form action="">
        <div class="row">
            <div class="col">
                <input type="text" class="form-control" placeholder="product name" aria-label="product name">
            </div>
        </div>
        <div class="row">
            <div class="col">
                <input type="file" class="form-control" placeholder="image" aria-label="image">
            </div>
        </div>
        <div class="row">
            <div class="col">
                <input type="text" class="form-control" placeholder="company name" aria-label="company name">
            </div>
        </div>
        <button type="submit" class="btn btn-primary">submit</button>
    </form>

<?php include("footer.php")?> 